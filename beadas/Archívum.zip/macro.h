#ifndef MACRO_H
#define MACRO_H

#include <iostream>
#include <string>
#include <cstdlib>  //kijelzo torleshez
#include "memtrace.h"
#include <iomanip>  
#include <fstream>
#include <sstream>

/* -------------------------------- TESTELES -------------------------------- */
#ifndef CPORTA
#define TESTELES true
#endif
/* -------------------------------------------------------------------------- */

#endif